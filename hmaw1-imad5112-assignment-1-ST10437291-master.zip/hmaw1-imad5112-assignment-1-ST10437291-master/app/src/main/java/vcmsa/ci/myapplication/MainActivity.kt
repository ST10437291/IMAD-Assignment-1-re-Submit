package vcmsa.ci.myapplication

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val timeSpinner = findViewById<Spinner>(R.id.timeSpinner)
        val suggestMealBtn = findViewById<Button>(R.id.suggestMealBtn)
        val resultText = findViewById<TextView>(R.id.resultText)
        val resetBtn = findViewById<Button>(R.id.resetBtn)

        // Define time of day options
        val timeOptions = arrayOf(
            "Morning",
            "Mid-morning",
            "Afternoon",
            "Mid-afternoon",
            "Dinner",
            "After Dinner Snack"
        )

        // Set up the spinner adapter
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, timeOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        timeSpinner.adapter = adapter

        suggestMealBtn.setOnClickListener { v: View? ->
            val timeOfDay = timeSpinner.selectedItem.toString()
            val mealSuggestion = when (timeOfDay) {
                "Morning" -> "Eggs on Toast, Pancakes with Honey, or Oatmeal with Berries"
                "Mid-morning" -> "Fruit Salad, Yogurt with Granola, or a Smoothie"
                "Afternoon" -> "Grilled Cheese Sandwich, Chicken Wrap, or a Garden Salad"
                "Mid-afternoon" -> "Chocolate Cake, Muffins, or Biscuits with Tea"
                "Dinner" -> "Pasta with Tomato Sauce, Grilled Chicken with Veggies, or Stir-fried Tofu with Rice"
                "After Dinner Snack" -> "Ice Cream, Popcorn, or Dark Chocolate"
                else -> "Invalid selection!"
            }
            resultText.text = mealSuggestion
        }

        resetBtn.setOnClickListener { v: View? ->
            timeSpinner.setSelection(0)
            resultText.text = "Meal suggestion will appear here"
        }
    }
}